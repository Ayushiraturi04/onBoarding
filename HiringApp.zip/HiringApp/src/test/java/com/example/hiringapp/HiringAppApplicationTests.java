package com.example.hiringapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HiringAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
